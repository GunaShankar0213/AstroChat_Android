package com.example.astrochat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.astrochat.Adapter.FragmentAdpater;
import com.example.astrochat.Adapter.UserAdapter;
import com.example.astrochat.Model.Users;
import com.example.astrochat.app_Activities.GroupChat;
import com.example.astrochat.app_Activities.Sign_In;
import com.example.astrochat.app_Activities.app_Settings;
import com.example.astrochat.databinding.ActivityMainBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    private FirebaseAuth mauth;
    SearchView searchView;
    FirebaseDatabase database=FirebaseDatabase.getInstance();
    ArrayList<Users> list = new ArrayList<>();
    ArrayList<Users> filteredlist = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mauth = FirebaseAuth.getInstance();
        // setting fragment adapters
        binding.viewpager.setAdapter(new FragmentAdpater(getSupportFragmentManager()));
        binding.tablayout.setupWithViewPager(binding.viewpager);


        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#FF6200EE"));

        // Set BackgroundDrawable
        assert actionBar != null;
        actionBar.setBackgroundDrawable(colorDrawable);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        MenuItem menuItem = menu.findItem(R.id.search_icon);
        searchView = (SearchView) menuItem.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query)
            {
                searchView.clearFocus();
                searchView.setQuery("",false);
                menuItem.collapseActionView();
               // Toast.makeText(MainActivity.this,"typed " +query,Toast.LENGTH_SHORT).show();

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                Toast.makeText(MainActivity.this,"typed "+newText,Toast.LENGTH_SHORT).show();
               filter(newText);

                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Settings:
                Intent intent2 = new Intent(MainActivity.this, app_Settings.class);
                startActivity(intent2);
                Toast.makeText(this, "Settings Pressed", Toast.LENGTH_SHORT).show();
                break;

            case R.id.groupchat:
                Toast.makeText(this, "Group Chat", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(MainActivity.this, GroupChat.class);
                startActivity(intent1);
                break;

            case R.id.Myevents:
                Toast.makeText(this, "Showing Events", Toast.LENGTH_SHORT).show();
                break;

            case R.id.Logout:
                mauth.signOut();
                Intent intent = new Intent(MainActivity.this, Sign_In.class);
                startActivity(intent);
                finish();
                Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void filter(String text) {
        // creating a new array list to filter our data.
        // running a for loop to compare elements.
            database.getReference().child("Users").addValueEventListener(new ValueEventListener() {
                @SuppressLint("NotifyDataSetChanged")
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    filteredlist.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                      Users  users = dataSnapshot.getValue(Users.class);
                        Objects.requireNonNull(users).setUid(dataSnapshot.getKey());
                        if (!users.getUid().equals(FirebaseAuth.getInstance().getUid()))
                        {
                            if (users.getUsername().toLowerCase().contains(text.toLowerCase()))
                            {
                                filteredlist.add(users);
                            }

                        }
                            Log.i("tagnew"," val: "+users.getUsername());
                            // checking if the entered string matched with any item of our recycler view.
                    }
                    UserAdapter adapter = new UserAdapter(filteredlist,MainActivity.this);
                    adapter.notifyDataSetChanged();

                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                    Toast.makeText(MainActivity.this, "Error in chats_frag", Toast.LENGTH_SHORT).show();
                }
            });

        if (filteredlist.isEmpty())
        {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(this, "No Data Found..", Toast.LENGTH_SHORT).show();
        }
        else {
            // at last we are passing that filtered
            // list to our adapter class.
            RecyclerView recyclerView = findViewById(R.id.recyclerview);
            UserAdapter adapter = new UserAdapter(filteredlist,MainActivity.this);
            adapter.filterList(filteredlist);
            recyclerView.setAdapter(adapter);

        }
        }

}




