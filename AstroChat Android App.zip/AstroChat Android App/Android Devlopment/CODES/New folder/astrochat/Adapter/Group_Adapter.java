package com.example.astrochat.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.astrochat.Model.Users;
import com.example.astrochat.R;
import com.example.astrochat.app_Activities.Chatuserdetail;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Group_Adapter  extends RecyclerView.Adapter<Group_Adapter.ViewHolder> implements Filterable
{
    ArrayList<Users> list;
    Context context;
    ArrayList<Users> selected_List = new ArrayList<>();



    public Group_Adapter(ArrayList<Users> list, Context context)
    {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public Group_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {

        View view= LayoutInflater.from(context).inflate(R.layout.group_user_layout,parent,false);
        return new ViewHolder(view);
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onBindViewHolder(@NonNull Group_Adapter.ViewHolder holder, int position) {

        Users users = list.get(position);

        Picasso.get().load(users.getProfilepic()).placeholder(R.drawable.avatar3).into(holder.image);
        holder.username.setText(users.getUsername());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, Chatuserdetail.class);
                intent.putExtra("userId",users.getUid());
                intent.putExtra("profilepic",users.getProfilepic());
                intent.putExtra("username",users.getUsername());
                context.startActivity(intent);
            }
        });


        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view)
            {
                Toast.makeText(view.getContext(),"Clicked On " +users.getUsername(),Toast.LENGTH_SHORT).show();
                users.setIschecked(!users.getIschecked());
                holder.view.setBackgroundColor(users.getIschecked() ? Color.DKGRAY : Color.WHITE);
                return true;
            }
        });



    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void filterList(ArrayList<Users> filterllist) {
        // below line is to add our filtered
        // list in our course array list.
        list = filterllist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }

    @Override
    public Filter getFilter() {
        return null;
    }


    public static class ViewHolder extends RecyclerView.ViewHolder{

        private View view;
        ImageView image;
        TextView username;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view =itemView;

            image = itemView.findViewById(R.id.chat_profile);
            username = itemView.findViewById(R.id.Chat_username);
        }
    }


}
