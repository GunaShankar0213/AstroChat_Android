package com.example.astrochat.Adapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.astrochat.Fragmnet.Calls_frag;
import com.example.astrochat.Fragmnet.Chats_frag;

public class FragmentAdpater extends FragmentPagerAdapter {
    public FragmentAdpater(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position)
    {
        switch (position)
        {
            case 0: return new Chats_frag();
            case 1: return new Calls_frag();
            default:return new Chats_frag();
        }

    }

    @Override
    public int getCount() {
        return 2;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String title = null;

        if (position==0)
        {
            title = "CHATS";
        }
        if (position==1)
        {
            title = "GROUPS";
        }
        return title;
    }
}

