package com.example.astrochat.Adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.astrochat.Model.MessageModel;
import com.example.astrochat.R;
import com.github.pgreze.reactions.ReactionPopup;
import com.github.pgreze.reactions.ReactionsConfig;
import com.github.pgreze.reactions.ReactionsConfigBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ChatAdapter extends RecyclerView.Adapter {

    Context context;
    ArrayList<MessageModel> messageModels;
    int sender_view_type = 1;
    int receiver_view_type = 2;
    int sender_view_type_image = 3;
    int receiver_view_type_image = 4;

    String recvId,senderroom,reciverroom;
    String name;
    FirebaseDatabase database = FirebaseDatabase.getInstance();


    public ChatAdapter(Context context, ArrayList<MessageModel> messageModels, String recvId,String senderroom,String reciverroom) {
        this.context = context;
        this.messageModels = messageModels;
        this.recvId = recvId;
        this.senderroom = senderroom;
        this.reciverroom = reciverroom;
    }
    public ChatAdapter(Context context, ArrayList<MessageModel> messageModels)
    {
        this.context = context;
        this.messageModels = messageModels;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        if (viewType == sender_view_type)
        {
            View view = LayoutInflater.from(context).inflate(R.layout.sample_chat_sender,parent,false);
            return new SenderViewHolder(view);
        }

        else
        {
            View view = LayoutInflater.from(context).inflate(R.layout.samplechat_reciver_duplicate,parent,false);
            return new ReceiverViewHolder(view);
        }
    }

    @Override
    public int getItemViewType(int position)
    {
        if (messageModels.get(position).getuId().equals(FirebaseAuth.getInstance().getUid()))
        {
            return sender_view_type;
        }

        else
         {
             return receiver_view_type;
         }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        MessageModel messageModel = messageModels.get(position);


        //to delete
        holder.itemView.setOnLongClickListener(view -> {

            new AlertDialog.Builder(context)
                    .setTitle("Delete")
                    .setMessage("Are You Sure Want To Delete The Message")
                    .setPositiveButton(Html.fromHtml(String.valueOf(Html.fromHtml("<font color='#80FF0000'>Myself</font>"))), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            FirebaseDatabase database = FirebaseDatabase.getInstance();
                            String senderroom = FirebaseAuth.getInstance().getUid() + recvId;
                            database.getReference().child("Chats").child(senderroom).child(messageModel.getMessageId()).setValue(null);
                        }
                    }).setNegativeButton(Html.fromHtml(String.valueOf(Html.fromHtml("<font color='#80FF0000'>Permanently</font>"))), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i)
                {
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    String senderroom = FirebaseAuth.getInstance().getUid() + recvId;
                    database.getReference().child("Chats").child(senderroom).child(messageModel.getMessageId()).child("message").setValue("Deleted Permanently");
                    database.getReference().child("Chats").child(reciverroom).child(messageModel.getMessageId()).child("message").setValue("Deleted Permanently");
                    dialogInterface.dismiss();
                }
            }).show();

            return false;
        });


        database.getReference().child("Users").child("timstamp").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot)
            {
                database.getReference().child("Users").child(recvId).child("timestamp").setValue(messageModel.getTimestamp());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

//      reaction emoji's
        int reactions[] = new int[]{
                R.drawable.ic_fb_like,
                R.drawable.ic_fb_love,
                R.drawable.ic_fb_laugh,
                R.drawable.ic_fb_wow,
                R.drawable.ic_fb_sad,
                R.drawable.ic_fb_angry,
                R.drawable.erase
        };

        ReactionsConfig config = new ReactionsConfigBuilder(context)
                .withReactions(reactions)
                .build();

        ReactionPopup popup = new ReactionPopup(context, config, (pos) -> {

            Log.i("postag","position org "+pos);

            if (pos==-1)
            {
                pos=6;
            }

            if (holder.getClass() == SenderViewHolder.class)
            {
                Log.i("postag","position1 "+pos);
                SenderViewHolder senderViewHolder = (SenderViewHolder) holder;

                Log.i("postag","position2 "+pos);
                if (reactions[pos]!=6)
                {senderViewHolder.fellings_sender.setImageResource(reactions[pos]);}
               senderViewHolder.fellings_sender.setVisibility(View.VISIBLE);
                Log.i("postag","position4 "+pos);
            }


            else
            {
                ReceiverViewHolder receiverViewHolder = (ReceiverViewHolder) holder;
                Log.i("postag","position3 "+pos);
                receiverViewHolder.fellings_reciver.setImageResource(reactions[pos]);
                if (pos != 6)
                {receiverViewHolder.fellings_reciver.setVisibility(View.VISIBLE);}
            }
            messageModel.setFeeling(pos);

            FirebaseDatabase.getInstance().getReference().child("Chats").child(senderroom).child(messageModel.getMessageId())
                    .setValue(messageModel);

            FirebaseDatabase.getInstance().getReference().child("Chats").child(reciverroom).child(messageModel.getMessageId())
                    .setValue(messageModel);
            return true; // true is closing popup, false is requesting a new selection
        });

        if (holder.getClass() == SenderViewHolder.class)
        {

            if (messageModel.getType().equals("text"))
            {

                ((SenderViewHolder)holder).sendermsg.setVisibility(View.VISIBLE);
                ((SenderViewHolder)holder).senderiv.setVisibility(View.GONE);
                ((SenderViewHolder)holder).sendermsg.setText(messageModel.getMessage());
            }
            else
            {
                ((SenderViewHolder)holder).sendermsg.setVisibility(View.GONE);
                ((SenderViewHolder)holder).senderiv.setVisibility(View.VISIBLE);
                //((SenderViewHolder)holder).senderiv.setImageURI(messageModel.getImages());

              Picasso.get().load(messageModel.getImages()).into(((SenderViewHolder) holder).senderiv);
            }


            Date date = new Date(messageModel.getTimestamp());
            @SuppressLint("SimpleDateFormat") SimpleDateFormat simpleDateFormat = new SimpleDateFormat("h:mm:a");
            String strdate = simpleDateFormat.format(date);

            ((SenderViewHolder)holder).sendertime.setText(strdate.toString());

            if(messageModel.getFeeling() >= 0 )
            {
                //messageModel.setFeeling(reactions[(int)messageModel.getFeeling()]);
                ((SenderViewHolder) holder).fellings_sender.setImageResource(reactions[messageModel.getFeeling()]);
                ((SenderViewHolder) holder).fellings_sender.setVisibility(View.VISIBLE);

                if (messageModel.getFeeling() == 6)
                {
                    ((SenderViewHolder) holder).fellings_sender.setVisibility(View.GONE);
                }
            }

            else
            {
                ((SenderViewHolder) holder).fellings_sender.setVisibility(View.GONE);
            }

            /*((SenderViewHolder) holder).sendermsg.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    popup.onTouch(view,motionEvent);
                    return false;
                }
            });*/

        }

        else
        {
            if (messageModel.getType().equals("text"))
            {
                ((ReceiverViewHolder)holder).recivermsg.setVisibility(View.VISIBLE);
                ((ReceiverViewHolder)holder).reciveriv.setVisibility(View.GONE);
                ((ReceiverViewHolder)holder).recivermsg.setText(messageModel.getMessage());
            }

            else
            {

                ((ReceiverViewHolder)holder).recivermsg.setVisibility(View.GONE);
                ((ReceiverViewHolder)holder).reciveriv.setVisibility(View.VISIBLE);
                Picasso.get().load(messageModel.getImages()).into(((ReceiverViewHolder) holder).reciveriv);

            }

            Date date = new Date(messageModel.getTimestamp());
            @SuppressLint("SimpleDateFormat") SimpleDateFormat simpleDateFormat = new SimpleDateFormat("h:mm:a");
            String strdate = simpleDateFormat.format(date);

            ((ReceiverViewHolder)holder).recivetime.setText(strdate);

            database.getReference().child("Users").child(messageModel.getuId()).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                     name = (String) snapshot.child("username").getValue();
                    ((ReceiverViewHolder)holder).reciverusername.setText(name);
                    Log.i("usertag","name " + name);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }

            });

            if(messageModel.getFeeling() >= 0 )
            {
                //messageModel.setFeeling(reactions[(int)messageModel.getFeeling()]);
                ((ReceiverViewHolder) holder).fellings_reciver.setImageResource(reactions[messageModel.getFeeling()]);
                ((ReceiverViewHolder) holder).fellings_reciver.setVisibility(View.VISIBLE);

                if (messageModel.getFeeling() == 6)
                {
                    ((ReceiverViewHolder) holder).fellings_reciver.setImageResource(reactions[messageModel.getFeeling()]);
                    ((ReceiverViewHolder) holder).fellings_reciver.setVisibility(View.GONE);
                }
            }

            else
            {
                ((ReceiverViewHolder) holder).fellings_reciver.setVisibility(View.GONE);
            }


            ((ReceiverViewHolder) holder).recivermsg.setOnTouchListener(new View.OnTouchListener() {
                @SuppressLint("ClickableViewAccessibility")
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                   try {
                       popup.onTouch(view, motionEvent);
                   }
                   catch (Exception e)
                   {
                       Toast.makeText(context.getApplicationContext(), ""+e, Toast.LENGTH_SHORT).show();
                   }
                    return false;
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return messageModels.size();
    }


    public static class ReceiverViewHolder extends RecyclerView.ViewHolder
    {
        TextView recivermsg,recivetime,reciverusername,udusername;
        ImageView fellings_reciver,reciveriv;

        public ReceiverViewHolder(@NonNull View itemView) {
            super(itemView);

                recivermsg = itemView.findViewById(R.id.recivertext);
                recivetime = itemView.findViewById(R.id.recivertime);
                reciverusername = itemView.findViewById(R.id.reciverusername);
            fellings_reciver = itemView.findViewById(R.id.fellings);
            reciveriv = itemView.findViewById(R.id.reciveriv);
            udusername = itemView.findViewById(R.id.ud_username);

        }
    }

    public static class SenderViewHolder extends RecyclerView.ViewHolder
    {
        TextView sendermsg,sendertime;
        ImageView fellings_sender,senderiv;


        public SenderViewHolder(@NonNull View itemView) {
            super(itemView);

            sendermsg = itemView.findViewById(R.id.senderText);
            sendertime = itemView.findViewById(R.id.sender_time);
            fellings_sender = itemView.findViewById(R.id.fellings);
            senderiv = itemView.findViewById(R.id.senderiv);

         }
    }

}
