package com.example.astrochat.Model;

import android.util.Log;

public class MessageModel {
    String uId,message,messageId,type;
    Long timestamp;
    String images;
        int feeling=-1;

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public MessageModel(String uId, String message, String messageId, Long timestamp, int feeling) {
        this.uId = uId;
        this.message = message;
        this.messageId = messageId;
        this.timestamp = timestamp;
        this.feeling = feeling;
    }

    public MessageModel(String uId, String message, Long timestamp) {
        this.uId = uId;
        this.message = message;
        this.timestamp = timestamp;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getFeeling() {
        return feeling;
    }

    public void setFeeling(int feeling) {
        this.feeling = feeling;
    }

    public MessageModel(String uId, String message) {
        this.uId = uId;
        this.message = message;
    Log.i("modeltag","id "+uId);
    }

    public MessageModel(){}

    public String getuId()
    {
        return uId;
    }

    public void setuId(String uId)
    {
        this.uId = uId;
    }

    public String getMessage() {

        Log.i("tagmark","message: "+message);
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
}
