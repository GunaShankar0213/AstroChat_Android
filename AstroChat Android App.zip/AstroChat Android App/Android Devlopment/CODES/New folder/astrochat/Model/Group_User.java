package com.example.astrochat.Model;

public class Group_User {

    String gname,uids,profilepic,desc,feeling;

    public Group_User(String gname, String uids, String profilepic, String desc, String feeling) {
        this.gname = gname;
        this.uids = uids;
        this.profilepic = profilepic;
        this.desc = desc;
        this.feeling = feeling;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getUids() {
        return uids;
    }

    public void setUids(String uids) {
        this.uids = uids;
    }

    public String getProfilepic() {
        return profilepic;
    }

    public void setProfilepic(String profilepic) {
        this.profilepic = profilepic;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getFeeling() {
        return feeling;
    }

    public void setFeeling(String feeling) {
        this.feeling = feeling;
    }
}
