package com.example.astrochat.Model;

public class Users {
    String profilepic,username,uid,mail,password,lastmessage,description="Hey,i am using AstroChat";
    Long timestamp;
    private Boolean ischecked = false;

    public Boolean getIschecked() {
        return ischecked;
    }

    public void setIschecked(Boolean ischecked) {
        this.ischecked = ischecked;
    }

    public Users() { }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public Users(String profilepic, String username, String uid, String mail, String password, String lastmessage) {
        this.profilepic = profilepic;
        this.username = username;
        this.uid = uid;
        this.mail = mail;
        this.password = password;
        this.lastmessage = lastmessage;
    }

    //signup
    public Users(String username, String mail, String password,String profilepic,String description) {
        this.username = username;
        this.mail = mail;
        this.password = password;
        this.profilepic = profilepic;
        this.description = description;
    }

    public Users(String profilepic, String username, String uid) {
        this.profilepic = profilepic;
        this.username = username;
        this.uid = uid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProfilepic() {
        return profilepic;
    }

    public void setProfilepic(String profilepic) {
        this.profilepic = profilepic;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLastmessage() {
        return lastmessage;
    }

    public void setLastmessage(String lastmessage) {
        this.lastmessage = lastmessage;
    }

}
