package com.example.astrochat.Fragmnet;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.astrochat.Adapter.UserAdapter;
import com.example.astrochat.Model.Users;
import com.example.astrochat.databinding.FragmentChatsFragBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;


public class Chats_frag extends Fragment {

    public Chats_frag() {
        // Required empty public constructor
    }

    FragmentChatsFragBinding binding;
    ArrayList<Users> list = new ArrayList<>();
    FirebaseDatabase database;
    Users users;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentChatsFragBinding.inflate(inflater, container, false);
        database = FirebaseDatabase.getInstance();
        UserAdapter adapter = new UserAdapter(list,getContext());
        binding.recyclerview.setAdapter(adapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        binding.recyclerview.setLayoutManager(layoutManager);

       database.getReference().child("Users").addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    users = dataSnapshot.getValue(Users.class);
                    Objects.requireNonNull(users).setUid(dataSnapshot.getKey());
                    if (!users.getUid().equals(FirebaseAuth.getInstance().getUid()))
                    {
                        list.add(users);
                    }
                    binding.progressbar.setVisibility(View.GONE);
                }
                adapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(getContext(), "Error in chats_frag", Toast.LENGTH_SHORT).show();
            }
        });



        return binding.getRoot();
    }
}



