package com.example.astrochat.app_Activities;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.astrochat.R;
import com.example.astrochat.databinding.ActivityUserDetailViewBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class user_detail_view extends AppCompatActivity {

    ActivityUserDetailViewBinding binding;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserDetailViewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

               Objects.requireNonNull(getSupportActionBar()).hide();

               binding.udUsername.setText(Chatuserdetail.getUd_username());
        Picasso.get().load(Chatuserdetail.getUd_Profilepic()).placeholder(R.drawable.avatar3).into(binding.udProfilepic);
        String ud_id = Chatuserdetail.getUd_id();

        database.getReference().child("Users").child(ud_id).child("description").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                binding.udDesc.setText(Objects.requireNonNull(snapshot.getValue()).toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(user_detail_view.this, "Error Occurred "+error , Toast.LENGTH_SHORT).show();
            }
        });

    }

}