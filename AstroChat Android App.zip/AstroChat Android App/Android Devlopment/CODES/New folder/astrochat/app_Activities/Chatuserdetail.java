package com.example.astrochat.app_Activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.astrochat.Adapter.ChatAdapter;
import com.example.astrochat.MainActivity;
import com.example.astrochat.Model.MessageModel;
import com.example.astrochat.R;
import com.example.astrochat.databinding.ActivityChatuserdetailBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class Chatuserdetail extends AppCompatActivity {

    private static String ud_username,ud_profile,ud_id;
    ActivityChatuserdetailBinding binding;
    FirebaseDatabase database;
    FirebaseAuth mauth;
    final static int camera_no = 123;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    private static final int CAMERA_REQUEST = 1888;
    String[] opt = {"Camera","Gallery"};
    Uri tempUri,tempUri1;
    final int PIC_CROP = 2;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityChatuserdetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Objects.requireNonNull(getSupportActionBar()).hide();
        database =FirebaseDatabase.getInstance();
        mauth = FirebaseAuth.getInstance();

        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#FF6200EE"));

        final String send_id = mauth.getUid();
        Log.i("detailtag","id : "+send_id);
        String reciverid = getIntent().getStringExtra("userId");
        String username = getIntent().getStringExtra("username");
        String profilepic = getIntent().getStringExtra("profilepic");
        Log.i("tagtag"," "+username);
        final String senderroom = send_id + reciverid;
        final  String reciverroom = reciverid + send_id;

        ud_username = username;
        ud_profile = profilepic;
        ud_id = reciverid;

        binding.username.setText(username);
        Picasso.get().load(profilepic).placeholder(R.drawable.avatar3).into(binding.profileimage);

        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Chatuserdetail.this, MainActivity.class);
                startActivity(intent);

            }
        });

        final ArrayList<MessageModel> messageModels= new ArrayList<>();

        final ChatAdapter chatAdapter = new ChatAdapter(this,messageModels,reciverid,senderroom,reciverroom);
        binding.chatRecyclerview.setAdapter(chatAdapter);

        LinearLayoutManager LayoutManager = new LinearLayoutManager(this);
        binding.chatRecyclerview.setLayoutManager(LayoutManager);



        database.getReference().child("Chats").child(senderroom)
                .addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                messageModels.clear();
                for(DataSnapshot snapshot1 : snapshot.getChildren())
                {

                    MessageModel model = snapshot1.getValue(MessageModel.class);
                    model.setMessageId(snapshot1.getKey());
                    messageModels.add(model);

                }
                 chatAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(Chatuserdetail.this, "Something Went wrong!", Toast.LENGTH_SHORT).show();
            }
        });


        binding.send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!binding.entermsg.getText().toString().equals(""))

                {
                    String message = binding.entermsg.getText().toString();
                Log.i("messagestag","message "+message);
                final MessageModel model = new MessageModel(send_id,message);
                model.setTimestamp(new Date().getTime());
                model.setType("text");
                binding.entermsg.setText("");
                Log.i("messagestag","message2 "+message);
                String randomkey = database.getReference().push().getKey();
                assert randomkey != null;
                database.getReference().child("Chats").child(senderroom).child(randomkey).setValue(model)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {

                                database.getReference().child("Chats").child(reciverroom).child(randomkey).setValue(model)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void unused) {
                                                               Toast.makeText(Chatuserdetail.this,"Sent the message",Toast.LENGTH_SHORT).show();
                                            }
                                        });
                            }
                        });
            }
                else
                {
                    Toast.makeText(Chatuserdetail.this,"Empty Messages Are Not Allowed",Toast.LENGTH_SHORT).show();
                }

            }
        });

       binding.entermsg.setOnTouchListener(new View.OnTouchListener() {
           @SuppressLint("ClickableViewAccessibility")
           @Override
           public boolean onTouch(View view, MotionEvent event) {
               final int DRAWABLE_LEFT = 0;
               final int DRAWABLE_TOP = 1;
               final int DRAWABLE_RIGHT = 2;
               final int DRAWABLE_BOTTOM = 3;

               if(event.getAction() == MotionEvent.ACTION_UP)
               {
                   if(event.getRawX() >= (binding.entermsg.getRight() - binding.entermsg.getCompoundDrawables()[DRAWABLE_LEFT].getBounds().width())) {
                       AlertDialog.Builder builder = new AlertDialog.Builder(Chatuserdetail.this);
                       builder.setTitle("Select A Option");
                       builder.setItems(opt, new DialogInterface.OnClickListener() {

                           @RequiresApi(api = Build.VERSION_CODES.M)
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               // the user clicked on colors[which]
                              if (opt[which].equals("Camera"))
                              {
                                  try
                                  {
                                      if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                                      {
                                          requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
                                      }
                                      else
                                      {
                                          Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                                          startActivityForResult(cameraIntent, MY_CAMERA_PERMISSION_CODE);
                                      }
                                  }

                                  catch (ActivityNotFoundException e)
                                  {
                                      Toast.makeText(Chatuserdetail.this,"Error: "+e,Toast.LENGTH_SHORT).show();
                                  }

                              }
                              if (opt[which].equals("Gallery"))
                              {
                                  Toast.makeText(Chatuserdetail.this,"Gallery",Toast.LENGTH_SHORT).show();
                                  try {
                                      Intent i = new Intent(
                                              Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                      startActivityForResult(i, camera_no);
                                  }
                                  catch (Exception e)
                                  {
                                      Toast.makeText(Chatuserdetail.this,"Error: "+e,Toast.LENGTH_SHORT).show();
                                  }
                              }
                           }
                       });
                       builder.show();

                       return true;
                   }
               }
               return false;
           }
       });

       binding.profileimage.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(Chatuserdetail.this,user_detail_view.class);
               startActivity(intent);
           }
       });

       binding.username.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(Chatuserdetail.this,user_detail_view.class);
               startActivity(intent);
           }
       });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE)
        {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            }
            else
            {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public String getRealPathFromURI(Uri uri) {
        String path = "";
        if (getContentResolver() != null) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst();
                int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                path = cursor.getString(idx);
                cursor.close();
            }
        }
        return path;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        final StorageReference profileImageRef = FirebaseStorage.getInstance().getReference("User_photos/" + System.currentTimeMillis() + ".jpg");

        if(requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (resultCode == RESULT_OK) {
                Log.i("mytag", "Code Recived");
                assert data != null;
                Bitmap photo = (Bitmap) data.getExtras().get("data");
                Log.i("mytag", "uri: " + photo.toString());
                // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
                tempUri = getImageUri(getApplicationContext(), photo);

                // CALL THIS METHOD TO GET THE ACTUAL PATH
                //File finalFile = new File(getRealPathFromURI(tempUri));
                Log.i("mytag", "str: " + tempUri);
                performCrop();


            }
        }

        if (requestCode == PIC_CROP) {
            Bundle extras = data.getExtras();
            //get the cropped bitmap
            Bitmap thePic = extras.getParcelable("data");
            tempUri1 = getImageUri(getApplicationContext(), thePic);
            Log.i("mytag", "uri1: " + tempUri1);
            ProgressDialog progressDialog = new ProgressDialog(Chatuserdetail.this);
            progressDialog.setTitle("Sending Image");
            progressDialog.setMessage("We are Processing the image with no compression");
            progressDialog.show();
            profileImageRef.putFile(tempUri1).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    profileImageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            String profileImageUrl = task.getResult().toString();
                            Log.i("mytag", profileImageUrl);

                            final MessageModel model = new MessageModel(mauth.getUid(), profileImageUrl);
                            model.setTimestamp(new Date().getTime());
                            model.setType("image");
                            String randomkey = database.getReference().push().getKey();
                            assert randomkey != null;
                            final String send_id = mauth.getUid();
                            Log.i("detailtag", "id : " + send_id);
                            String reciverid = getIntent().getStringExtra("userId");
                            String username = getIntent().getStringExtra("username");
                            final String senderroom = send_id + reciverid;
                            final String reciverroom = reciverid + send_id;
                            model.setImages(profileImageUrl);
                            database.getReference().child("Chats").child(senderroom).child(randomkey).setValue(model)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            database.getReference().child("Chats").child(reciverroom).child(randomkey).setValue(model)
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void unused) {
                                                            progressDialog.dismiss();
                                                            Toast.makeText(Chatuserdetail.this, "Sent the image", Toast.LENGTH_SHORT).show();
                                                        }
                                                    });
                                        }
                                    });

                        }
                    });
                }
            });


        }



        if (requestCode == camera_no && resultCode == RESULT_OK && data.getData()!=null && data != null)
        {
            Uri sFile = data.getData();
            Log.i("mytag","uri: " + sFile.toString());
            Log.i("mytag","uri: " + sFile.getLastPathSegment());
            ProgressDialog progressDialog = new ProgressDialog(Chatuserdetail.this);
            progressDialog.setTitle("Sending Image");
            progressDialog.setMessage("We are Processing the image with no compression");
            progressDialog.show();
            profileImageRef.putFile(sFile).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    profileImageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            String profileImageUrl=task.getResult().toString();
                            Log.i("mytag",profileImageUrl);

                            final MessageModel model = new MessageModel(mauth.getUid(),profileImageUrl);
                            model.setTimestamp(new Date().getTime());
                            model.setType("image");
                            String randomkey = database.getReference().push().getKey();
                            assert randomkey != null;
                            final String send_id = mauth.getUid();
                            Log.i("detailtag","id : "+send_id);
                            String reciverid = getIntent().getStringExtra("userId");
                            String username = getIntent().getStringExtra("username");
                            final String senderroom = send_id + reciverid;
                            final  String reciverroom = reciverid + send_id;
                            model.setImages(profileImageUrl);
                            database.getReference().child("Chats").child(senderroom).child(randomkey).setValue(model)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            database.getReference().child("Chats").child(reciverroom).child(randomkey).setValue(model)
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void unused) {
                                                            progressDialog.dismiss();
                                                            Toast.makeText(Chatuserdetail.this,"Sent the image",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });
                                        }
                                    });

                        }
                    });
                }
            });

        }
    }
    protected static String getUd_username()
    {
        return ud_username;
    }

    protected static String getUd_Profilepic()
    {
        return ud_profile;
    }
    public static String getUd_id()
    {
        return ud_id;
    }

    private void performCrop()
    {
        Intent cropIntent = new Intent("com.android.camera.action.CROP");
        cropIntent.setDataAndType(tempUri, "image/*");
        //set crop properties
        cropIntent.putExtra("crop", "true");
        //indicate aspect of desired crop
        cropIntent.putExtra("aspectX", 1);
        cropIntent.putExtra("aspectY", 1);
        //indicate output X and Y
        cropIntent.putExtra("outputX", 256);
        cropIntent.putExtra("outputY", 256);
        //retrieve data on return
        cropIntent.putExtra("return-data", true);
        //start the activity - we handle returning in onActivityResult
        startActivityForResult(cropIntent, PIC_CROP);
    }
}

