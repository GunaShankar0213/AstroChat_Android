package com.example.astrochat.app_Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.astrochat.R;
import com.example.astrochat.databinding.ActivityAppSettingsBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class app_Settings extends AppCompatActivity {

    ActivityAppSettingsBinding binding;
    FirebaseDatabase database;
    FirebaseAuth mAuth;
   Task<DataSnapshot> reference;
   String settings_username,setting_desc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAppSettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Objects.requireNonNull(getSupportActionBar()).hide();
        database = FirebaseDatabase.getInstance();
        mAuth = FirebaseAuth.getInstance();

         reference = database.getReference().child("Users").child(Objects.requireNonNull(mAuth.getUid())).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
             @Override
             public void onComplete(@NonNull Task<DataSnapshot> task) {
                 if (task.isSuccessful())
                 {
                     if (task.getResult().exists())
                     {
                         DataSnapshot snapshot = task.getResult() ;
                         settings_username = String.valueOf(snapshot.child("username").getValue());
                         setting_desc = String.valueOf(snapshot.child("description").getValue());
                         //setting values
                         binding.settingsUsername.setText(settings_username);
                         binding.settingsUsernameDesc.setText(setting_desc);
                         Picasso.get().load(String.valueOf(snapshot.child("profilepic").getValue())).placeholder(R.drawable.avatar3).into(binding.SettingsProfilepic);
                     }
                 }
             }
         });


         binding.editFab.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent intent = new Intent(app_Settings.this,settings_pop.class);
                 startActivity(intent);
                 finish();
             }
         });
    }

}