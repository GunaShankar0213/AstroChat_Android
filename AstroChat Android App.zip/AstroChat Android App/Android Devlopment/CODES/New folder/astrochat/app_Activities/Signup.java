package com.example.astrochat.app_Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.astrochat.Model.Users;
import com.example.astrochat.R;
import com.example.astrochat.databinding.ActivitySignupBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class Signup extends AppCompatActivity {

    ActivitySignupBinding binding;
    private FirebaseAuth mauth;
    private FirebaseDatabase database;
    ProgressDialog progressDialog;
    private static int RESULT_LOAD_IMAGE = 10;
    Uri selectedImage;
    String imagestring;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Objects.requireNonNull(getSupportActionBar()).hide();

        mauth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        FirebaseUser Fuser = mauth.getCurrentUser();

        progressDialog = new ProgressDialog(Signup.this);
        progressDialog.setTitle("Creating Account ");
        progressDialog.setMessage("Just Wait For A Moment");

        binding.btnSignup.setOnClickListener(view -> {
            progressDialog.dismiss();



            if (binding.txtpassword.getText().toString().length() < 6 )
            {
                showerror(binding.txtpassword);
            }

            if(!binding.txtemail.getText().toString().isEmpty() && !binding.txtpassword.getText().toString().isEmpty()
                    && !binding.txtusername.getText().toString().isEmpty() && binding.txtpassword.getText().toString().length() <= 6)
            {
                mauth.createUserWithEmailAndPassword(binding.txtemail.getText().toString(),binding.txtpassword.getText().toString())
                        .addOnCompleteListener(task -> {
                            if(task.isSuccessful())
                            {
                                Users user = new Users(binding.txtusername.getText().toString(),
                                        binding.txtemail.getText().toString(),
                                        binding.txtpassword.getText().toString(),imagestring,"Hey,i am using AstroChat");

                                String id = Objects.requireNonNull(task.getResult().getUser()).getUid();
                                database.getReference().child("Users").child(id).setValue(user);

                                Toast.makeText(Signup.this,"Success",Toast.LENGTH_SHORT).show();
                            }
                            else
                            {
                                Toast.makeText(Signup.this, Objects.requireNonNull(task.getException()).toString(),Toast.LENGTH_SHORT).show();
                            }
                        });
            }

            else
            {
                Toast.makeText(Signup.this, "Enter The Credentials", Toast.LENGTH_SHORT).show();
            }
        });
        binding.txtalreadyhaveaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Signup.this, Sign_In.class);
                startActivity(intent);
                finish();
            }
        });

        binding.imagSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(
                        Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });
    }

    private void showerror(EditText txtpassword)
    {
        txtpassword.setError("Minimum 6 char required");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            ImageView imageView = (ImageView) findViewById(R.id.imag_signup);
            imageView.setImageURI(selectedImage);
            imagestring = selectedImage.toString();
        }
    }
}