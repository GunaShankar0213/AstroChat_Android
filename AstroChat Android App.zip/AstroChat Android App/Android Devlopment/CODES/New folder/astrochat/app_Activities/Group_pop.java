package com.example.astrochat.app_Activities;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.astrochat.Adapter.Group_Adapter;
import com.example.astrochat.Model.Users;
import com.example.astrochat.R;
import com.example.astrochat.databinding.ActivityAddGroupUsersPopBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

public class Group_pop extends AppCompatActivity {

    ActivityAddGroupUsersPopBinding binding;
    SearchView searchView;
    ArrayList<Users> list = new ArrayList<>();
    ArrayList<Users> filteredlist = new ArrayList<>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    Users users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddGroupUsersPopBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#FF6200EE"));
        assert actionBar != null;
        actionBar.setBackgroundDrawable(colorDrawable);


        Group_Adapter adapter = new Group_Adapter(list,Group_pop.this);
        binding.groupUsers.setAdapter(adapter);

        LinearLayoutManager layoutManager  = new LinearLayoutManager(Group_pop.this);
        binding.groupUsers.setLayoutManager(layoutManager);


        database.getReference().child("Users").addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot)
            {
                list.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    users = dataSnapshot.getValue(Users.class);
                    Objects.requireNonNull(users).setUid(dataSnapshot.getKey());
                    if (!users.getUid().equals(FirebaseAuth.getInstance().getUid()))
                    {
                        list.add(users);
                    }



                    binding.groupPbar.setVisibility(View.GONE);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error)
            {
                Toast.makeText(Group_pop.this, "Error in chats_frag", Toast.LENGTH_SHORT).show();
            }
        });


        binding.groupCreateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                database.getReference().child("Groups").child(binding.groupTitle.getText().toString()).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        database.getReference().child("Groups").child(binding.groupTitle.getText().toString()).child("Group_UsedBy").setValue(users);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.group_menu, menu);

        MenuItem menuItem = menu.findItem(R.id.search_group);
        searchView = (SearchView) menuItem.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query)
            {
                searchView.clearFocus();
                searchView.setQuery("",false);
                menuItem.collapseActionView();


                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                Toast.makeText(Group_pop.this,"typed "+newText,Toast.LENGTH_SHORT).show();
                filter(newText);

                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }


    private void filter(String text) {
        // creating a new array list to filter our data.
        // running a for loop to compare elements.
        database.getReference().child("Users").addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                filteredlist.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Users  users = dataSnapshot.getValue(Users.class);
                    Objects.requireNonNull(users).setUid(dataSnapshot.getKey());
                    if (!users.getUid().equals(FirebaseAuth.getInstance().getUid()))
                    {
                        if (users.getUsername().toLowerCase().contains(text.toLowerCase()))
                        {
                            filteredlist.add(users);
                        }

                    }
                    Log.i("tagnew"," val: "+users.getUsername());
                    // checking if the entered string matched with any item of our recycler view.
                }
                Group_Adapter adapter = new Group_Adapter(filteredlist, Group_pop.this);
                adapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(Group_pop.this, "Error in chats_frag", Toast.LENGTH_SHORT).show();
            }
        });

        if (filteredlist.isEmpty())
        {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(this, "No Data Found..", Toast.LENGTH_SHORT).show();
        }
        else
            {
            // at last we are passing that filtered
            // list to our adapter class.
            RecyclerView recyclerView = findViewById(R.id.group_users);
            Group_Adapter adapter = new Group_Adapter(filteredlist,Group_pop.this);
            adapter.filterList(filteredlist);
            recyclerView.setAdapter(adapter);
        }
    }

}