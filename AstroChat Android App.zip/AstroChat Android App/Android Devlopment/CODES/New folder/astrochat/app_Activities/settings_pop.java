package com.example.astrochat.app_Activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.astrochat.Model.Users;
import com.example.astrochat.R;
import com.example.astrochat.databinding.ActivitySettingsPopBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class settings_pop extends AppCompatActivity {


    private static final int RESULT_LOAD_IMAGE = 10;
    String org_username,username_new,org_desc,desc;
    ActivitySettingsPopBinding binding;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    FirebaseAuth auth = FirebaseAuth.getInstance();
    FirebaseStorage storage =FirebaseStorage.getInstance();
    Task<DataSnapshot> ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsPopBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Objects.requireNonNull(getSupportActionBar()).hide();

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.8), (int)(height *.6));

        binding.circleImageViewPop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    Intent i = new Intent(
                            Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(i, RESULT_LOAD_IMAGE);
                }
                catch (Exception e)
                {
                    Toast.makeText(settings_pop.this,"Error: "+e,Toast.LENGTH_SHORT).show();
                }


            }
        });

        ref = database.getReference().child("Users").child(Objects.requireNonNull(auth.getUid())).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful())
                {
                    if (task.getResult().exists())
                    {
                        DataSnapshot snapshot = task.getResult() ;
                        org_username = String.valueOf(snapshot.child("username").getValue());
                        org_desc = String.valueOf(snapshot.child("description").getValue());
                        Log.i("imgtag","name: "+org_username);
                        binding.etUsernamePop.setText(org_username);
                        binding.etDescPop.setText(org_desc);
                        //setting values
                    }
                }
            }
        });

        database.getReference().child("Users").child(auth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Users users = snapshot.getValue(Users.class);
                assert users != null;
                Picasso.get().load(users.getProfilepic()).placeholder(R.drawable.avatar3).into(binding.circleImageViewPop);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });




        binding.savePop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!binding.etUsernamePop.getText().toString().isEmpty()  && !binding.etDescPop.getText().toString().isEmpty())
                {
                    username_new = binding.etUsernamePop.getText().toString();
                    desc = binding.etDescPop.getText().toString();
                    ref = database.getReference().child("Users").child(Objects.requireNonNull(auth.getUid())).get()
                            .addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            if (task.isSuccessful())
                            {
                                if (task.getResult().exists())
                                {
                                    DataSnapshot snapshot = task.getResult();
                                    database.getReference().child("Users").child(auth.getUid()).child("username").setValue(username_new);
                                    database.getReference().child("Users").child(auth.getUid()).child("description").setValue(desc);

                                    database.getReference().child("Users").child(auth.getUid()).addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            Users users = snapshot.getValue(Users.class);
                                            assert users != null;
                                            Picasso.get().load(users.getProfilepic()).placeholder(R.drawable.avatar3).into(binding.circleImageViewPop);
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {

                                        }

                                    });
                                }
                            }
                        }
                    });
                }
                Intent intent = new Intent(settings_pop.this,app_Settings.class);
                startActivity(intent);
            }
        });

        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(settings_pop.this,app_Settings.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (resultCode==-1 && data.getData()!=null)
        {
            Uri sFile = data.getData();
            binding.circleImageViewPop.setImageURI(sFile);
            final StorageReference reference = storage.getReference().child("Profile_User_Pic")
                    .child(Objects.requireNonNull(auth.getUid()));
            reference.putFile(sFile).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            database.getReference().child("Users").child(auth.getUid()).child("profilepic")
                                    .setValue(uri.toString());
                        }
                    });
                }
            });
        }
        else
        {
            Toast.makeText(settings_pop.this, "Process Failed To Upload", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onBackPressed()
    {
        startActivity(new Intent(this, app_Settings.class));
        finish();
    }
}